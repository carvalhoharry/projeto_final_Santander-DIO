# Fundamentos de Segurança da Informação (Base de Conhecimento)

Este documento define os conceitos fundamentais que devem guiar todas as análises, diagnósticos e recomendações de segurança.

## 1. Conceitos Centrais (Equação do Risco)
* **Ativo:** Qualquer recurso de valor que precisa ser protegido (dados de usuários, código-fonte, servidores, credenciais, disponibilidade do serviço).
* **Vulnerabilidade:** Uma fraqueza ou falha no design, implementação, configuração ou controle de um sistema que pode ser explorada. (Ex: consulta SQL sem parametrização, porta administrativa exposta sem autenticação).
* **Ameaça:** Qualquer agente, circunstância ou evento com potencial para explorar uma vulnerabilidade e causar dano (Ex: atacantes externos automatizados, usuários mal-intencionados, falhas humanas).
* **Risco:** A probabilidade de uma ameaça explorar uma vulnerabilidade específica e o impacto resultante para o negócio ou ambiente. **Risco = Probabilidade × Impacto.**

## 2. Tríade CIA (Confidencialidade, Integridade e Disponibilidade)
Toda análise de impacto deve avaliar quais pilares da tríade são afetados:
* **Confidencialidade:** Garantia de que a informação seja acessada apenas por pessoas ou sistemas autorizados. *(Falha típica: vazamento de banco de dados, exposição de chaves de API).*
* **Integridade:** Garantia de que os dados e sistemas não sejam alterados, corrompidos ou destruídos de forma não autorizada. *(Falha típica: adulteração de registros via SQL Injection, modificação de binários).*
* **Disponibilidade:** Garantia de que sistemas e dados estejam acessíveis e operacionais quando necessários. *(Falha típica: ataques de negação de serviço - DoS, ransomware).*

## 3. Critérios de Avaliação (Severidade)
Ao classificar uma falha, utilize a seguinte matriz qualitativa:
* **Probabilidade (Baixa / Média / Alta):** Considera a facilidade de exploração, necessidade de autenticação prévia, exposição na rede (internet vs. rede interna) e existência de ferramentas públicas de exploração.
* **Impacto (Baixo / Médio / Alto):** Considera a sensibilidade dos dados expostos, o nível de privilégio obtido (usuário comum vs. root/admin) e o comprometimento da tríade CIA.
* **Severidade Final (Crítica / Alta / Média / Baixa):** Resultado combinado da probabilidade com o impacto no contexto específico informado pelo usuário.

## 4. Princípios Defensivos
* **Menor Privilégio (Least Privilege):** Usuários, processos e serviços devem operar apenas com as permissões estritamente necessárias.
* **Defesa em Profundidade (Defense in Depth):** Não depender de uma única camada de proteção; combinar validação na aplicação, controles de rede, autenticação forte e monitoramento/logs.
* **Seguro por Padrão (Secure by Default):** Configurações iniciais devem ser restritivas; serviços e portas desnecessários devem permanecer desativados.