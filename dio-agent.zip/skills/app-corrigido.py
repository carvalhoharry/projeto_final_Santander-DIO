import sqlite3
import hashlib
import secrets


ADMIN_USER = "admin"
ADMIN_PASSWORD = "senha_lab_123"
USER_USER = "aluno"
USER_PASSWORD = "lab_user_456"


def _hash_password(password: str, salt: bytes | None = None, iterations: int = 120_000):
    """Gera (salt, digest) usando PBKDF2-HMAC-SHA256.

    O sal é gerado aleatoriamente a cada chamada, o que impede ataques de
    *rainbow table*. Aumente o número de iterações conforme a capacidade do
    hardware. Para produção, prefira bcrypt, scrypt ou argon2 (bibliotecas
    especializadas que gerenciam o "cost factor" e a adaptabilidade).
    """
    if salt is None:
        salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, iterations
    )
    return salt, digest


def init_db():
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password_salt BLOB NOT NULL,
            password_hash BLOB NOT NULL,
            role TEXT NOT NULL
        )
    """)
    # As senhas são armazenadas como (salt, digest) — nunca em texto puro.
    # O restante do código só verifica o hash; a senha original nunca é
    # recuperada nem comparada na query.
    admin_salt, admin_digest = _hash_password(ADMIN_PASSWORD)
    cursor.execute(
        "INSERT INTO users (username, password_salt, password_hash, role) VALUES (?, ?, ?, ?)",
        (ADMIN_USER, admin_salt, admin_digest, "admin"),
    )
    user_salt, user_digest = _hash_password(USER_PASSWORD)
    cursor.execute(
        "INSERT INTO users (username, password_salt, password_hash, role) VALUES (?, ?, ?, ?)",
        (USER_USER, user_salt, user_digest, "user"),
    )
    conn.commit()
    return conn


def login_segura(conn, username: str, password: str):
    """Autentica com query parametrizada e verificação de senha via hash.

    Correção principal: username e password são enviados como parâmetros (?),
    nunca interpolados dentro da string SQL. O SQLite trata o valor
    literalmente — uma cadeia como ' OR '1'='1' NÃO é interpretada como parte
    do comando.

    A senha também não é comparada diretamente no banco. O banco retorna o
    hash salvo; a comparação acontece em memória com secrets.compare_digest,
    o que impede vazamento de bits via timing attack.
    """
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, username, password_salt, password_hash, role "
        "FROM users WHERE username = ?",
        (username,),
    )
    row = cursor.fetchone()
    if row is None:
        # Resposta genérica: o mesmo resultado é retornado para usuário
        # inexistente e senha inválida, para dificultar o "user
        # enumeration" (descoberta de quais usuários existem).
        return None

    user_id, username, salt, stored_hash, role = row
    _, computed_digest = _hash_password(password, salt)
    if secrets.compare_digest(computed_digest, stored_hash):
        return row
    return None


if __name__ == "__main__":
    conexao = init_db()
    entrada_usuario = input("Usuário: ")
    entrada_senha = input("Senha: ")

    resultado = login_segura(conexao, entrada_usuario, entrada_senha)
    if resultado:
        print(
            f"Acesso permitido! "
            f"Usuário: {resultado[1]} | Perfil: {resultado[4]}"
        )
    else:
        print("Credenciais inválidas.")
    conexao.close()