import sqlite3
import hashlib
import secrets
import os


def _hash_password(password: str, salt: bytes | None = None, iterations: int = 120_000):
    """Gera (salt, digest) usando PBKDF2-HMAC-SHA256.

    O sal e gerado aleatoriamente a cada chamada, o que impede ataques de
    *rainbow table*. Aumente o numero de iteracoes conforme a capacidade do
    hardware. Para producao, prefira bcrypt, scrypt ou Argon2, que gerenciam
    o cost factor e a adaptabilidade automaticamente.
    """
    if salt is None:
        salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, iterations
    )
    return salt, digest


def init_db():
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password_salt BLOB NOT NULL,
            password_hash BLOB NOT NULL,
            role TEXT NOT NULL
        )
    """)
    # Senhas sao armazenadas como (salt, digest) — nunca em texto puro.
    admin_salt, admin_digest = _hash_password("senha_lab_123")
    cursor.execute(
        "INSERT INTO users (username, password_salt, password_hash, role) "
        "VALUES (?, ?, ?, ?)",
        ("admin", admin_salt, admin_digest, "admin"),
    )
    user_salt, user_digest = _hash_password("lab_user_456")
    cursor.execute(
        "INSERT INTO users (username, password_salt, password_hash, role) "
        "VALUES (?, ?, ?, ?)",
        ("aluno", user_salt, user_digest, "user"),
    )
    conn.commit()
    return conn


def login_segura(conn, username: str, password: str):
    """Autentica com query parametrizada e verificacao de senha via hash.

    Correcao principal: username e password sao enviados como parametros (?),
    nunca interpolados dentro da string SQL. O SQLite trata o valor literalmente
    — uma cadeia como ' OR '1'='1' Nao e interpretada como parte do comando.

    A senha nao e comparada diretamente no banco. O banco retorna o hash salvo;
    a comparacao acontece em memoria com secrets.compare_digest, o que impede
    vazamento de bits via timing attack.
    """
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, username, password_salt, password_hash, role "
        "FROM users WHERE username = ?",
        (username,),
    )
    row = cursor.fetchone()
    if row is None:
        # Resposta generica: o mesmo resultado e retornado para usuario inexistente
        # e senha invalida, para dificultar o user enumeration (descoberta de
        # quais usuarios existem).
        return None

    user_id, stored_username, salt, stored_hash, role = row
    _, computed_digest = _hash_password(password, salt)
    if secrets.compare_digest(computed_digest, stored_hash):
        return row
    return None


if __name__ == "__main__":
    conexao = init_db()
    entrada_usuario = input("Usuario: ")
    entrada_senha = input("Senha: ")

    resultado = login_segura(conexao, entrada_usuario, entrada_senha)
    if resultado:
        print(
            f"Acesso permitido! "
            f"Usuario: {resultado[1]} | Perfil: {resultado[4]}"
        )
    else:
        print("Credenciais invalidas.")
    conexao.close()
