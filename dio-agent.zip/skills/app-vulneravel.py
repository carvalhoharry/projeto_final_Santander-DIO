import sqlite3


def init_db():
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    """)
    # Apenas para laboratório local — nunca use senhas em texto puro em sistemas reais
    cursor.execute(
        "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
        ("admin", "senha_lab_123", "admin"),
    )
    cursor.execute(
        "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
        ("aluno", "lab_user_456", "user"),
    )
    conn.commit()
    return conn


def login_vulneravel(conn, username: str, password: str):
    cursor = conn.cursor()
    # FALHA: Montagem da query via f-string / concatenação direta de entrada do usuário
    query = (
        f"SELECT id, username, role FROM users "
        f"WHERE username = '{username}' AND password = '{password}'"
    )
    print(f"[DEBUG SQL] {query}")
    cursor.execute(query)
    return cursor.fetchone()


if __name__ == "__main__":
    conexao = init_db()
    entrada_usuario = input("Usuário: ")
    entrada_senha = input("Senha: ")

    resultado = login_vulneravel(conexao, entrada_usuario, entrada_senha)
    if resultado:
        print(f"Acesso permitido! Usuário: {resultado[1]} | Perfil: {resultado[2]}")
    else:
        print("Credenciais inválidas.")
    conexao.close()