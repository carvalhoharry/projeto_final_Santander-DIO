# Skill: `security-testing`

Esta skill complementa a análise de vulnerabilidades ajudando o usuário a **comprovar que uma correção funcionou** por meio de testes estruturados em laboratório.

## O que ela faz
1. **Valida o escopo:** Garante que os testes ocorram apenas em ambiente local ou de laboratório controlado.
2. **Estrutura casos de teste:** Divide a validação entre fluxos legítimos, casos negativos e testes de resiliência de entrada, evitando regressões funcionais.
3. **Define critérios de aprovação:** Indica quais evidências (logs, respostas seguras, ausência de erros internos) confirmam a mitigação.