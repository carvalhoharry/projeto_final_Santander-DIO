import os
import sqlite3
import tempfile
import threading
import time
from contextlib import contextmanager

from fastapi import (
    FastAPI,
    Request,
    HTTPException,
    Depends,
    status,
)
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

import bcrypt

# ============================================================================
# DIO Agente — Autenticação Web Segura
# ============================================================================
# Substitui o login CLI (skills/app.py) por um endpoint HTTP com as seguintes
# proteções:
#   1. Parametrização de SQL (nenhum dado é interpetrado como comando).
#   2. Armazenamento de senha via bcrypt (sal + hash, nunca texto puro).
#   3. Rate limiting por IP (janelas deslizantes) para dificultar força-bruta.
#   4. Mensagens genéricas de erro (sem user enumeration).
#   5. Sessão assinada via cookie (HttpOnly, SameSite), sem expor a senha.
# ============================================================================

app = FastAPI(title="DIO Agente — Login Seguro")

# --------------------------- CONFIGURAÇÃO (ambiente) -------------------------
# Em produção, sempre defina SECRET_KEY e DATABASE_URL via variável de
# ambiente. SECRET_KEY é usado para assinar os tokens de sessão.
SECRET_KEY: str = os.environ.get("SECRET_KEY", "")
if not SECRET_KEY:
    # Só para desenvolvimento. Em produção, o segredo deve vir de um
    # gerenciador de segredos e NÃO deve ser o valor padrão.
    SECRET_KEY = os.environ.get("SECRET_KEY", "") or os.urandom(32).hex()
    print(
        "[AVISO] SECRET_KEY não informado: o app usou um valor aleatório "
        "que é recalculado a cada reinício (válido apenas em dev)."
    )

BCRYPT_ROUNDS: int = int(os.environ.get("BCRYPT_ROUNDS", "12"))
MAX_LOGIN_ATTEMPTS: int = int(os.environ.get("MAX_LOGIN_ATTEMPTS", "5"))
RATE_LIMIT_WINDOW_SEC: int = int(os.environ.get("RATE_LIMIT_WINDOW_SEC", "60"))

# Ambiente de execução: "production" ou "development".
APP_ENV: str = os.environ.get("APP_ENV", "development").lower()
COOKIE_SECURE: bool = APP_ENV == "production"

# Banco de dados. Por padrão usa um arquivo temporário (persiste entre
# requisições). Defina DATABASE_URL para alterar o banco.
def _resolve_db_path(url: str) -> tuple[str, str | None]:
    """Normaliza a URL de conexão SQLite.

    Retorna (modo, caminho):
      * ':memory:' -> memória (válido apenas até o término da conexão);
      * 'file'     -> caminho de arquivo (padrão de produção).
    """
    if not url.startswith("sqlite:///"):
        return "file", url
    inner = url[len("sqlite:///"):]
    if inner in (":memory:", ""):
        return ":memory:", None
    rel = inner[1:] if inner.startswith("/") else inner
    return "file", rel

DB_MODE, DB_PATH = _resolve_db_path(
    os.environ.get(
        "DATABASE_URL",
        os.path.join(tempfile.gettempdir(), "dio_agent_login.db"),
    )
)
print(f"[INFO] Banco de dados: {DB_MODE} -> {DB_PATH}")
